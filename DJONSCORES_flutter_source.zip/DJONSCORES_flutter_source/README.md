# DJONSCORES — prototype Flutter

Interface Flutter initiale en français, thème sombre premium noir/or/vert, conçue pour démarrer une application Android compatible avec Android 8.0 (API 26).

## Contenu actuel
- Écran Matchs, Pronostics, Statistiques et Compte.
- Favoris en mémoire pendant la session.
- Estimation de score locale illustrative à partir de valeurs fictives.
- Aucun compte, paiement, notification push, flux de résultats en direct ou API sportive n'est connecté à ce stade.

**Important :** les matchs et scores sont des données de démonstration. Ce prototype ne fournit pas de vrais pronostics ni de garantie de gain. Les paiements MTN Mobile Money / Orange Money ne doivent être activés qu'après ouverture et vérification d'un compte marchand, configuration des secrets côté serveur et validation des paiements par webhook serveur.

## Générer le projet Android et l'APK
Prérequis : Flutter SDK stable, Android SDK, Android Studio / outils de compilation.

1. Extraire l'archive sur un ordinateur.
2. Dans le dossier `DJONSCORES_flutter_source`, exécuter :

```bash
flutter create . --platforms=android --org cm.djonscores
flutter pub get
```

3. Dans `android/app/build.gradle` (ou `build.gradle.kts` selon le modèle Flutter), régler `minSdk` à `26` pour Android 8.0 minimum.
4. Compiler :

```bash
flutter build apk --release
```

APK généré normalement dans `build/app/outputs/flutter-apk/app-release.apk`.

Pour une APK universelle, ne pas ajouter `--split-per-abi`. Tester sur le Galaxy S7 avant diffusion.

## Étapes indispensables avant une version publique
1. Authentification et rôles administrateur côté serveur (ne jamais intégrer un mot de passe administrateur en dur dans l'application).
2. Base de données et API sécurisée.
3. Source de données sportives sous licence et gestion de ses limites de quota.
4. Moteur de prédiction validé sur des données historiques ; afficher les limites et l'incertitude.
5. Abonnements, période d'essai et paiements Mobile Money avec vérification serveur et gestion des remboursements.
6. Notifications push, politique de confidentialité, conditions d'utilisation et tests de sécurité.

## Compatibilité
Le code utilise Flutter Material 3 et des widgets standard. La configuration Android définitive doit être générée avec une version stable de Flutter puis testée sur Android 8.0. Le poids de l'APK dépendra de la version Flutter, des bibliothèques et des architectures incluses ; aucune taille précise n'est garantie.
